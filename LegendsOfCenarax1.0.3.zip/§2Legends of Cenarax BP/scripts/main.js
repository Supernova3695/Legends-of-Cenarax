import "./item_trigger";
import { world } from "@minecraft/server"
import { ActionFormData } from "@minecraft/server-ui"

const customUi = new ActionFormData()
    .title("Legends of Cenarax Settings")
    .body("Select Something Here")
    .button("Scoreboard", "textures/ui/custom_ui/scoreboard_button_glyph")
    .button("Shop", "textures/ui/icon_deals")
    .button("Ban Tool", "textures/ui/hammer_l");



world.afterEvents.itemUse.subscribe(async (event) => {
    const { source, itemStack } = event
    switch (itemStack.typeId) {
        case "locdev:locdev_settings": {
            const res = await customUi.show(source);
            res.selection //This Is Number Will Be Derived From The "collection_index" property of a button in JSON UI
            world.sendMessage(`Button ${res.selection} Has Been Pressed!`)
            break

        };

    }

})

